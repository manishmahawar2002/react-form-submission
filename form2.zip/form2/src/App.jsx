import { useState } from 'react'
// import reactLogo from './assets/react.svg'
// import viteLogo from '/vite.svg'
// import './App.css'
import Navbar from './component/Navbar'
import Home from './component/Home'
import Signin from './component/Signin'
import Signup from './component/Signup'
import protext from './component/Protext'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import Protext from './component/Protext'

let router = createBrowserRouter([{
  path: '/',
  element: <div>
    <Navbar/>
    <Signup></Signup>
   </div>,
  index: true
},
{
  path: '/home',
  element: <div>
    <Navbar/>
    <Home/>
  </div>
},
{
  path: '/signup',
  element: <div>
    <Navbar/>
    <Protext>
        <Signup/>
        </Protext>
   
  
    
     </div>
},
{
  path: '/signin',
  element:  <div>
   
    <Navbar/>
    
    <Signin/>
  </div>
}
])

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <RouterProvider router={router}></RouterProvider>

     
    </>
  )
}

export default App
