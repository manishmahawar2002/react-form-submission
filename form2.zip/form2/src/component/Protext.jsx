import React from 'react'
import { Navigate } from 'react-router-dom';

export default function Protext() {
    let auth = JSON.parse(localStorage.getItem('isLoggedin'));
     return auth? <Navigate to="/"/> :<Navigate to="/signin"/>
      
    
}
