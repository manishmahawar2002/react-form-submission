import React from 'react'
import { useNavigate } from 'react-router-dom';
// import { useNavigate } from 'react-router-dom';

export default function Home() {
   let userData =  JSON.parse(localStorage.getItem('user'));
   let navigateLogout = useNavigate()
   let logout = ()=>{
    localStorage.setItem('isLoggedin', false)
    navigateLogout('/signup')
   }
  return (
    <div>
        <h1>home</h1>
        <p>{userData.name}</p>
         <p>{userData.email}</p>
          <p>{userData.password}</p>
          <button onClick={logout}>Logout</button>
      
    </div>
  )
}
